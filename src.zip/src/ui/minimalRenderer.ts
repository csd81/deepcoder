import { renderRaw } from "./rawMode.js";
import { charWidth, displayWidth } from "./charWidth.js";

/**
 * Phase 10A — minimal TUI renderer (pure frame builder + key mapping).
 *
 * This module is fully deterministic: no I/O, no ANSI escape codes, no
 * dependencies.  It builds the frame lines that a downstream I/O layer would
 * write to the terminal.
 */

/** Strip ANSI from a string when `raw` is true. */
function stripIfRaw(raw: boolean | undefined, s: string): string {
  return raw ? renderRaw(s) : s;
}

// ── FrameInput ───────────────────────────────────────────────────────────────

export interface FrameInput {
  /** Text for the status bar (first line). */
  statusLine: string;
  /** All transcript lines (the full scrollable content). */
  lines: string[];
  /** Index into `lines` for the first visible row. */
  viewportTop: number;
  /** Number of rows available for the visible window (excluding status bar and input line). */
  height: number;
  /** Terminal width in columns — every output line is truncated to this. */
  width: number;
  /** Current input line text (single-line composer). */
  inputLine: string;
  /** Multiline composer rows; when present, used instead of `inputLine`. */
  inputLines?: string[];
  /** Whether there is new output below the viewport (show indicator). */
  hasNewOutputBelow: boolean;
  /** Slash-command dropdown rows, rendered just above the composer when open. */
  menuLines?: string[];
  /** File-completion dropdown rows, rendered just above the composer when open (same position as menuLines). */
  completerLines?: string[];
  /** Footer hint line, rendered as the very last row when present. */
  footerLine?: string;
  /** When true, strip ANSI escape codes from all lines before rendering. */
  raw?: boolean;
}

// ── renderFrame ──────────────────────────────────────────────────────────────

/**
 * Build the frame lines for the TUI.
 *
 * Returns an array of strings:
 *   [0]              — status bar (truncated to `width`)
 *   [1..height]      — visible window of `lines` sliced from `viewportTop`
 *   [maybe indicator] — "↓ new output below" line (only when `hasNewOutputBelow`)
 *   [last]           — input line (truncated to `width`)
 *
 * Every returned line is truncated to `width` columns.
 */
export function renderFrame(input: FrameInput): string[] {
  const { statusLine, lines, viewportTop, height, width, inputLine, hasNewOutputBelow, raw } = input;
  const result: string[] = [];

  // 1. Status bar
  result.push(truncate(stripIfRaw(raw, statusLine), width));

  // 2. Visible window
  const visible = lines.slice(viewportTop, viewportTop + height);
  for (const line of visible) {
    result.push(truncate(stripIfRaw(raw, line), width));
  }

  // Pad remaining rows in the visible window if we have fewer lines than height
  const remainingRows = height - visible.length;
  for (let i = 0; i < remainingRows; i++) {
    result.push(truncate("", width));
  }

  // 3. "New output below" indicator
  if (hasNewOutputBelow) {
    result.push(truncate(stripIfRaw(raw, "↓ new output below"), width));
  }

  // 4. Slash-command dropdown or file-completion dropdown (above the composer, when open)
  if (input.menuLines) {
    for (const row of input.menuLines) result.push(truncate(stripIfRaw(raw, row), width));
  }
  if (input.completerLines) {
    for (const row of input.completerLines) result.push(truncate(row, width));
  }

  // 5. Input composer (one or more rows)
  const composer = input.inputLines ?? [inputLine];
  for (const row of composer) result.push(truncate(stripIfRaw(raw, row), width));

  // 6. Footer hint line (very last row)
  if (input.footerLine !== undefined) result.push(truncate(stripIfRaw(raw, input.footerLine), width));

  return result;
}

// ── keyToAction ──────────────────────────────────────────────────────────────

export type KeyAction =
  | "scroll-up"
  | "scroll-down"
  | "half-up"
  | "half-down"
  | "top"
  | "bottom"
  | "history-up"
  | "history-down"
  | "escape"
  | "submit"
  | "interrupt"
  | "none";

/**
 * Map a key string to a semantic action.
 *
 * Accepts both readline-style key names (e.g. "pageup", "home") and raw
 * escape sequences where applicable.
 */
export function keyToAction(key: string): KeyAction {
  switch (key) {
    // PageUp / PageDown
    case "pageup":
    case "\u001b[5~":
      return "scroll-up";

    case "pagedown":
    case "\u001b[6~":
      return "scroll-down";

    // Ctrl+U / Ctrl+D (half-page)
    case "\u0015": // Ctrl+U
      return "half-up";

    case "\u0004": // Ctrl+D
      return "half-down";

    // Home / End
    case "home":
    case "\u001b[H":
    case "\u001b[1~":
      return "top";

    case "end":
    case "\u001b[F":
    case "\u001b[4~":
      return "bottom";

    // Up / Down — prompt history navigation
    case "up":
      return "history-up";

    case "down":
      return "history-down";

    // Escape
    case "escape":
    case "\u001b":
      return "escape";

    // Enter
    case "return":
    case "enter":
    case "\r":
    case "\n":
      return "submit";

    // Ctrl+C
    case "\u0003": // Ctrl+C
      return "interrupt";

    default:
      return "none";
  }
}

// ── Helpers ──────────────────────────────────────────────────────────────────

/**
 * Visible column count of a string, ignoring SGR color codes (which take no
 * screen space). CJK / fullwidth / emoji count as two columns, combining and
 * zero-width marks as none — see {@link displayWidth}.
 */
export function visibleWidth(s: string): number {
  return displayWidth(s);
}

/**
 * Truncate a string to at most `maxLen` VISIBLE columns, preserving any SGR
 * color codes and appending a reset if the string was cut while styled. Lines
 * that already fit (by visible width) are returned unchanged.
 *
 * Width is measured in display columns: a wide (CJK/emoji) character that would
 * straddle the limit is dropped whole rather than overflowing or being split,
 * and surrogate pairs are never cut in half.
 */
export function truncate(s: string, maxLen: number): string {
  if (visibleWidth(s) <= maxLen) return s;
  let out = "";
  let count = 0;
  let i = 0;
  let sawEscape = false;
  while (i < s.length && count < maxLen) {
    const m = /^\x1b\[[0-9;]*m/.exec(s.slice(i));
    if (m) {
      out += m[0];
      i += m[0].length;
      sawEscape = true;
      continue;
    }
    const cp = s.codePointAt(i)!;
    const ch = String.fromCodePoint(cp);
    const w = charWidth(cp);
    if (count + w > maxLen) break; // a wide char would overflow — stop before it
    out += ch;
    i += ch.length; // advance past the whole code point (surrogate-pair safe)
    count += w;
  }
  return sawEscape ? out + "\x1b[0m" : out;
}
