/**
 * Phase 10A — pure transcript reducer.
 *
 * This module is fully deterministic: no I/O, no stdout, no random, no dates.
 * All timestamps are provided by the caller (or use a fixed sentinel for
 * testing).
 */

import type { UiEvent, UiConfig, UiStatus } from "./events.js";
import { DEFAULT_UI_CONFIG } from "./events.js";

// ── Helpers ─────────────────────────────────────────────────────────────────

let _nextId = 0;
/** Deterministic ID generator — resets on each process start. */
function nextId(): string {
  return `b${++_nextId}`;
}

/** Reset the ID counter (used in tests). */
export function _resetIds(): void {
  _nextId = 0;
}

// ── TranscriptBlock ─────────────────────────────────────────────────────────

export interface TranscriptBlock {
  id: string;
  kind: "user" | "assistant" | "tool" | "check" | "worker" | "notice" | "approval" | "system";
  /** External key (check name / worker id) used to match streaming updates. */
  refId?: string;
  title?: string;
  body: string;
  /** Byte-cap truncation marker (set by enforceCaps); distinct from `expanded`. */
  collapsed?: boolean;
  /** User toggled this collapsible block open to show its full body ("logs"). */
  expanded?: boolean;
  isError?: boolean;
  startedAt: string;
  finishedAt?: string;
}

// ── TranscriptState ─────────────────────────────────────────────────────────

export interface TranscriptState {
  blocks: TranscriptBlock[];
  status: UiStatus;
  atBottom: boolean;
  hasNewOutputBelow: boolean;
  totalBytes: number;
  /** id of the focused collapsible block (Tab cursor), or null. */
  selectedBlockId: string | null;
}

// ── createTranscript ────────────────────────────────────────────────────────

export function createTranscript(_config?: UiConfig): TranscriptState {
  return {
    blocks: [],
    status: {},
    atBottom: true,
    hasNewOutputBelow: false,
    totalBytes: 0,
    selectedBlockId: null,
  };
}

// ── Selection / expand (collapsible blocks: tool / check / worker) ────────────

const COLLAPSIBLE_KINDS = new Set(["tool", "check", "worker"]);

/** Move the focus cursor across collapsible blocks, skipping the rest. */
export function moveSelection(state: TranscriptState, dir: 1 | -1): TranscriptState {
  const idxs = state.blocks
    .map((b, i) => (COLLAPSIBLE_KINDS.has(b.kind) ? i : -1))
    .filter((i) => i >= 0);
  if (idxs.length === 0) return state;
  const curIdx = state.blocks.findIndex((b) => b.id === state.selectedBlockId);
  let target: number;
  if (curIdx < 0) {
    target = dir > 0 ? idxs[0] : idxs[idxs.length - 1];
  } else {
    const pos = idxs.indexOf(curIdx);
    const newPos = Math.min(idxs.length - 1, Math.max(0, pos + dir));
    target = idxs[newPos];
  }
  return { ...state, selectedBlockId: state.blocks[target].id };
}

/** Clear the focus cursor. */
export function clearSelection(state: TranscriptState): TranscriptState {
  return { ...state, selectedBlockId: null };
}

/** Focus a block by id (e.g. from a mouse click); no-op if the id is unknown. */
export function selectBlockById(state: TranscriptState, id: string): TranscriptState {
  if (!state.blocks.some((b) => b.id === id)) return state;
  return { ...state, selectedBlockId: id };
}

/** Toggle the `expanded` flag on the focused block. */
export function toggleExpand(state: TranscriptState): TranscriptState {
  if (state.selectedBlockId == null) return state;
  const blocks = state.blocks.map((b) =>
    b.id === state.selectedBlockId ? { ...b, expanded: !b.expanded } : b,
  );
  return { ...state, blocks };
}

// ── applyEvent ──────────────────────────────────────────────────────────────

const MAX_BLOCKS = 500;

/**
 * Apply a single UiEvent to the transcript, returning a **new** state
 * (immutable update).
 */
export function applyEvent(
  state: TranscriptState,
  event: UiEvent,
  config: UiConfig = DEFAULT_UI_CONFIG,
): TranscriptState {
  switch (event.type) {
    // ── assistant_delta ──────────────────────────────────────────────────
    case "assistant_delta": {
      const blocks = [...state.blocks];
      const lastIdx = blocks.length - 1;
      let newTotalBytes = state.totalBytes;

      if (lastIdx >= 0 && blocks[lastIdx].kind === "assistant" && blocks[lastIdx].finishedAt === undefined) {
        // Coalesce into the current open assistant block (a FINISHED block — even
        // with the falsy "" sentinel — must never be reopened, so a new message
        // after assistant_done starts its own block).
        const prev = blocks[lastIdx];
        const newBody = prev.body + event.text;
        const delta = newBody.length - prev.body.length;
        blocks[lastIdx] = { ...prev, body: newBody };
        newTotalBytes += delta;
      } else {
        // Start a new assistant block
        const block: TranscriptBlock = {
          id: nextId(),
          kind: "assistant",
          body: event.text,
          startedAt: "",
        };
        blocks.push(block);
        newTotalBytes += event.text.length;
      }

      return enforceCaps(
        { ...state, blocks, totalBytes: newTotalBytes },
        config,
      );
    }

    // ── assistant_done ───────────────────────────────────────────────────
    case "assistant_done": {
      const blocks = [...state.blocks];
      const lastIdx = blocks.length - 1;
      if (lastIdx >= 0 && blocks[lastIdx].kind === "assistant" && blocks[lastIdx].finishedAt === undefined) {
        const prev = blocks[lastIdx];
        let newBody = prev.body;
        let newTotalBytes = state.totalBytes;
        if (event.text !== undefined) {
          const delta = event.text.length;
          newBody += event.text;
          newTotalBytes += delta;
        }
        blocks[lastIdx] = { ...prev, body: newBody, finishedAt: "" };
        return { ...state, blocks, totalBytes: newTotalBytes };
      }
      return state;
    }

    // ── tool_start ───────────────────────────────────────────────────────
    case "tool_start": {
      const block: TranscriptBlock = {
        id: nextId(),
        kind: "tool",
        title: event.name,
        body: "",
        startedAt: "",
      };
      const blocks = [...state.blocks, block];
      return enforceCaps({ ...state, blocks }, config);
    }

    // ── tool_result ──────────────────────────────────────────────────────
    case "tool_result": {
      const block: TranscriptBlock = {
        id: nextId(),
        kind: "tool",
        title: event.name,
        body: event.output,
        isError: event.isError,
        startedAt: "",
        finishedAt: "",
      };
      const blocks = [...state.blocks, block];
      const newTotalBytes = state.totalBytes + event.output.length;
      return enforceCaps(
        { ...state, blocks, totalBytes: newTotalBytes },
        config,
      );
    }

    // ── notice ───────────────────────────────────────────────────────────
    case "notice": {
      const block: TranscriptBlock = {
        id: nextId(),
        kind: "notice",
        body: event.message,
        startedAt: "",
      };
      const blocks = [...state.blocks, block];
      const newTotalBytes = state.totalBytes + event.message.length;
      return enforceCaps({ ...state, blocks, totalBytes: newTotalBytes }, config);
    }

    // ── approval_request ─────────────────────────────────────────────────
    case "approval_request": {
      const block: TranscriptBlock = {
        id: nextId(),
        kind: "approval",
        title: event.description,
        body: event.diff ?? "",
        startedAt: "",
      };
      const blocks = [...state.blocks, block];
      const newTotalBytes = state.totalBytes + (event.diff ?? "").length;
      return enforceCaps({ ...state, blocks, totalBytes: newTotalBytes }, config);
    }

    // ── approval_result ──────────────────────────────────────────────────
    case "approval_result": {
      // Find the last open approval block and close it
      const blocks = state.blocks.map((b) => {
        if (b.kind === "approval" && !b.finishedAt) {
          return { ...b, finishedAt: "", body: event.approved ? "approved" : "denied" };
        }
        return b;
      });
      return { ...state, blocks };
    }

    // ── check_start / output / done ──────────────────────────────────────
    case "check_start": {
      const block: TranscriptBlock = {
        id: nextId(), kind: "check", refId: event.name, title: event.name, body: "", startedAt: "",
      };
      return enforceCaps({ ...state, blocks: [...state.blocks, block] }, config);
    }
    case "check_output": {
      const blocks = updateOpen(state.blocks, "check", event.name, (b) => ({ ...b, body: b.body + event.chunk }));
      return enforceCaps({ ...state, blocks, totalBytes: state.totalBytes + event.chunk.length }, config);
    }
    case "check_done": {
      const blocks = updateOpen(state.blocks, "check", event.name, (b) => ({ ...b, finishedAt: "", isError: !event.passed }));
      return { ...state, blocks };
    }

    // ── worker_start / update / done ─────────────────────────────────────
    case "worker_start": {
      const block: TranscriptBlock = {
        id: nextId(), kind: "worker", refId: event.id, title: event.label, body: "", startedAt: "",
      };
      return enforceCaps({ ...state, blocks: [...state.blocks, block] }, config);
    }
    case "worker_update": {
      const blocks = updateOpen(state.blocks, "worker", event.id, (b) => ({ ...b, body: event.status }));
      return { ...state, blocks };
    }
    case "worker_done": {
      const blocks = updateOpen(state.blocks, "worker", event.id, (b) => ({ ...b, finishedAt: "", body: event.summary }));
      return enforceCaps({ ...state, blocks, totalBytes: state.totalBytes + event.summary.length }, config);
    }

    // ── status ───────────────────────────────────────────────────────────
    case "status": {
      const newStatus = { ...state.status, ...event.patch };
      return { ...state, status: newStatus };
    }

    default:
      return state;
  }
}

/**
 * Find the most-recent OPEN block of `kind` with the given `refId` and apply
 * `fn` to it, returning a new blocks array. No match -> unchanged.
 */
function updateOpen(
  blocks: TranscriptBlock[],
  kind: TranscriptBlock["kind"],
  refId: string,
  fn: (b: TranscriptBlock) => TranscriptBlock,
): TranscriptBlock[] {
  const out = [...blocks];
  for (let i = out.length - 1; i >= 0; i--) {
    if (out[i].kind === kind && out[i].refId === refId && !out[i].finishedAt) {
      out[i] = fn(out[i]);
      return out;
    }
  }
  return out;
}

// ── Collapse & cap enforcement ──────────────────────────────────────────────

/**
 * Walk the blocks list and:
 *  1. Mark any block whose body exceeds `collapseToolOutputAfterBytes` as
 *     collapsed, retaining a head+tail slice.
 *  2. Enforce MAX_BLOCKS by evicting oldest blocks.
 *  3. Enforce `transcriptMaxBytes` by evicting oldest blocks.
 *
 * Returns a new state (shallow copies).
 */
function enforceCaps(
  state: TranscriptState,
  config: UiConfig,
): TranscriptState {
  let { blocks, totalBytes } = state;
  const collapseThreshold = config.collapseToolOutputAfterBytes;
  const maxBytes = config.transcriptMaxBytes;

  // 1. Collapse large blocks — recalculate totalBytes to reflect the new body sizes
  let bytesAdjustment = 0;
  blocks = blocks.map((b) => {
    if (b.body.length > collapseThreshold && !b.collapsed) {
      const head = b.body.slice(0, 2000);
      const tail = b.body.slice(-1000);
      const newBody = head + "\n... [collapsed, " + b.body.length + " bytes total] ...\n" + tail;
      bytesAdjustment += newBody.length - b.body.length;
      return {
        ...b,
        collapsed: true,
        body: newBody,
      };
    }
    return b;
  });
  totalBytes += bytesAdjustment;

  // 2. Enforce max blocks (evict oldest)
  while (blocks.length > MAX_BLOCKS) {
    const removed = blocks.shift()!;
    totalBytes -= removed.body.length;
  }

  // 3. Enforce max total bytes (evict oldest)
  while (totalBytes > maxBytes && blocks.length > 0) {
    const removed = blocks.shift()!;
    totalBytes -= removed.body.length;
  }

  // Clamp to zero (shouldn't go negative but be safe)
  if (totalBytes < 0) totalBytes = 0;

  // Scroll/follow logic
  let { atBottom, hasNewOutputBelow } = state;
  if (atBottom) {
    // Following — stays at bottom
    hasNewOutputBelow = false;
  } else {
    // User scrolled up — mark new output below
    hasNewOutputBelow = true;
  }

  return {
    ...state,
    blocks,
    totalBytes,
    atBottom,
    hasNewOutputBelow,
  };
}

// ── Scroll helpers ──────────────────────────────────────────────────────────

/**
 * Mark the transcript as having scrolled away from the bottom.
 */
export function scrollUp(state: TranscriptState): TranscriptState {
  return { ...state, atBottom: false, hasNewOutputBelow: false };
}

/**
 * Mark the transcript as having returned to the bottom (auto-follow).
 */
export function scrollToBottom(state: TranscriptState): TranscriptState {
  return { ...state, atBottom: true, hasNewOutputBelow: false };
}
